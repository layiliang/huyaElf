package com.lyl.webElf.consts;

public class PageNameConsts {
	public static final String HOST_PAGE = "hostPage";
	public static final String USER_MAIN_PAGE = "userMainPage";
	public static final String LIVE_PAGE = "livePage";
}
