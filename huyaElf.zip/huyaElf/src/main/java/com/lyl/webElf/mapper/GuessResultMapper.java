package com.lyl.webElf.mapper;

import com.lyl.webElf.domain.GuessResult;

public interface GuessResultMapper {
	void insert(GuessResult guessResult);
}
