package com.lyl.webElf.consts;

import java.util.Set;

public class HuyaElfConst {
	public static Set<String> treasureUrls ;
	public static final String MAIN_PAGE_FOR_DIGGER="https://www.huya.com/bdcmovie";
	public static final String MAIN_PAGE_FOR_FINDDER="https://www.huya.com/bdcmovie";
	public static final String LIVE_PAGE_FOR_EXAMPLE=MAIN_PAGE_FOR_FINDDER;
	public static final String USER_LEVEL_PAGE="https://i.huya.com/index.php?m=UserLevel";
	public static final String[] LIVE_PAGE_FOR_SENDGIFT={"https://www.huya.com/bdcmovie","https://www.huya.com/11342412","https://www.huya.com/adgll"};

}
