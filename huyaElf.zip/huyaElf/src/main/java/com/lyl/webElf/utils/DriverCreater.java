package com.lyl.webElf.utils;

import org.openqa.selenium.WebDriver;

public interface DriverCreater {

	WebDriver createDriver();

}
