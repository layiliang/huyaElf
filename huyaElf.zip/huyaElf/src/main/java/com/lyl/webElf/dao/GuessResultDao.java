package com.lyl.webElf.dao;

import com.lyl.webElf.domain.GuessResult;

public interface GuessResultDao {

	void insert(GuessResult guessResult);

}
