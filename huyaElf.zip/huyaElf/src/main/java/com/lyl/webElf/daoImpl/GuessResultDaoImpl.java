package com.lyl.webElf.daoImpl;

import org.springframework.stereotype.Component;

import com.lyl.webElf.dao.GuessResultDao;
import com.lyl.webElf.domain.GuessResult;
@Component("guessResultDao")
public class GuessResultDaoImpl implements GuessResultDao {

	@Override
	public void insert(GuessResult guessResult) {
		// TODO Auto-generated method stub
		
	}

}
