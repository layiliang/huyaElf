package com.lyl.webElf.consts;

public class LoginModeConsts {
	public static final String ACCOUNT_MODE = "accountMode";
	public static final String PHONE_MODE = "phoneMode";
}
