create table live_item(
	id varchar(50),
	num varchar(50),
	title varchar(50),
	isOnTv varchar(50),
	isGuess varchar(50),
	hostName  varchar(50),
	url varchar(50),
	groupId varchar(50),
	hostName varchar(50)
)