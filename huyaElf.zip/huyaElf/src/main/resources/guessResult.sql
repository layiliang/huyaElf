create table guess_result(
	id varchar(50),
	gameId varchar(50),
	Date TIMESTAMP,
	endRate1 NUMERIC,
	endNum1 INTEGER,
	guessName1 varchar(50),
	result1 varchar(50),
	endRate2 NUMERIC,
	endNum2 INTEGER,
	guessName2 varchar(50),
	result2 varchar(50),
	hostName varchar(50)
)