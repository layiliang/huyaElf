﻿$("body").append("<a href='' id ='newUrl'  target='_blank'>newUrl</a>")


