﻿<div id="J_treasureChestContainer" class="treasureChestContainer">
	<div class="liveRoom_treasureChest">
		<div class="box">
			<img src="https://huyaimg.msstatic.com/cdnimage/actprop/20269_1_0_prop_web_countdown_1553669084.png" alt="宝箱">
		</div>
		<i class="num" style="display: none;">1</i>
		<p class="btn-wrap">
			<span class="btn">00:01</span>
		</p>
		<div class="waitTips">
			<p class="tit">
				<span class="nick">梦然</span>
				<span class="aName">的空投箱</span>
			</p>
			<div class="cont">
				<p>领取还未开始，请耐心等待~</p>
				<p>多发弹幕可提高中奖概率哦！</p>
			</div>
			<i class="arrow"></i>
		</div>
	</div>
</div>

$("#J_treasureChestContainer .num").text();